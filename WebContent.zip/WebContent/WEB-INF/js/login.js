$(function(){
	//UIkit.icon('.toprightico').svg.then(function(svg) { svg.querySelector('path').style.stroke = 'white'; })
	
	$('#loginBtn').click(function(){
		window.location.href = "login1?name="+$('#userName').val()+"&psw="+$("#password").val();
	});
	$('.register').click(function(){
		window.location.href = "register";
	});
});
