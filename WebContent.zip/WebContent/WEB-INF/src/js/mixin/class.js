import { addClass } from '../util/index';

export default {

    init() {
        addClass(this.$el, this.$name);
    }

};
